﻿using Domain.Models;
using Joker.Contracts.$safeprojectname$;
using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer.EFCore
{
  public interface ISampleDbContext : IContext, IDbTransactionFactory
  {
    public DbSet<Book> Books { get; set; }
  }
}