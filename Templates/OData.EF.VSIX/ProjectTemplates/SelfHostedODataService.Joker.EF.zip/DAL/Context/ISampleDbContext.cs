﻿using System.Data.Entity;
using Domain.Models;
using Joker.Contracts.Data;

namespace $safeprojectname$.Context
{
  public interface ISampleDbContext : IContext, IDbTransactionFactory
  {
    IDbSet<Book> Books { get; set; }
  }
}