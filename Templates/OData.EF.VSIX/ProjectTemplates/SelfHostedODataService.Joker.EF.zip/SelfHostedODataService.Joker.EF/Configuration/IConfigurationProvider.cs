﻿namespace $safeprojectname$.Configuration
{
  public interface IConfigurationProvider
  {
    string GetDatabaseConnectionString();
    string RedisUrl { get; }
  }
}